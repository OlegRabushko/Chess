export const TITLE = 'React Chess'
