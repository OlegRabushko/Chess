import { createStore } from 'redux'
import * as R from 'ramda'

export default R.curry(createStore)
