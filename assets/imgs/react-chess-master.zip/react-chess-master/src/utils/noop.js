function noop () {}

export default noop
